#include<bits/stdc++.h>
using namespace std;

/*
JusPay January Hackerearth Q1 
Correct 30/30
*/

void floydWarshall(vector<vector<int> >&ad,int n){
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++)
        if(ad[i][j]==0) ad[i][j]=INT_MAX;
    }

    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(ad[i][j]!=INT_MAX){
				for(int k=0;k<n;k++)
				{
					if(ad[j][k]!=INT_MAX){
						ad[i][k]=min(ad[i][k], ad[i][j]+ad[j][k]);
					}
				}
			}
        }
    }
}

int main(){
    int n,e,x,y;
    cin>>n;
    vector<int>nodes(n);
    map<int,int>m;
    for(int i=0;i<n;i++) cin>>nodes[i],m[nodes[i]]=i;
    vector<vector<int> >ad(n,vector<int>(n,0));
    cin>>e;
    for(int i=0;i<e;i++){
        cin>>x>>y;
        ad[m[x]][m[y]]=1;
    }
    floydWarshall(ad,n);
    int u,v;
    cin>>u>>v;
    cout<<((ad[m[u]][m[v]]!=INT_MAX)?1:0)<<endl;
    return 0;
}
